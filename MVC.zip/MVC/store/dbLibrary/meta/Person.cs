﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace db.meta
{
    public class Person
    {
        public string Name { get; set; }
        public List<Parent> Parent { get; set; }
    }

    // 子对象模型
    public class Parent
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }
}
