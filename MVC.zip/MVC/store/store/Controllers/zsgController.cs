﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using db;
using store.Controllers;
using store.Uitl.Filters;

namespace store.Controllers
{
    public class zsgController : BaseController
    {
        //
        // GET: /zsg/
        [OutputCache(Duration = 10)]
        public ActionResult List()
        {
            List<db.Books> list = db.bill.books.GetBooks();
            string Timing = TimingActionFilter.Timing;
            ViewData["Timing"] = Timing;
            ViewBag.Timing = Timing;
            return View(list);
        }

        //图书新增
        [HttpGet]
        public ActionResult insert1()
        {
            return View();
        }
        [HttpPost]
        public ActionResult insert1(db.Books books)
        {
            db.bill.books.insert1(books);
            return RedirectToAction("List");
        }
        [HttpGet]
        public ActionResult insert2()
        {
            return View();
        }
        [HttpPost]
        public ActionResult insert2(string bookname, string title, Nullable<decimal> Price)
        {
            db.bill.books.insert2(bookname, title, Price);
            return RedirectToAction("List");
        }
        
        //图书修改
        [HttpGet]
        public ActionResult update1(int bookid)
        {
            db.Books books= db.bill.books.GetEntry(bookid);
            return View(books);
        }
        [HttpPost]
        public ActionResult update1(db.Books books)
        {
            db.bill.books.update1(books);
            return RedirectToAction("List");
        }

        [HttpGet]
        public ActionResult update2(int bookid)
        {
            db.Books books = db.bill.books.GetEntry(bookid);
            return View(books);
        }
        [HttpPost]
        public ActionResult update2(db.Books books)
        {
            db.bill.books.update2(books);
            return RedirectToAction("List");
        }

        [HttpGet]
        public ActionResult update3(int bookid)
        {
            db.Books books = db.bill.books.GetEntry(bookid);
            return View(books);
        }
        [HttpPost]
        public ActionResult update3(int bookid,string AuthorName, string title, Nullable<decimal> Price)
        {
            db.bill.books.update3(bookid , AuthorName, title, Price);
            return RedirectToAction("List");
        }

        public ActionResult delete(int bookid)
        {
            db.bill.books.delete(bookid);
            return RedirectToAction("List");
        }
        public ActionResult detail(int bookid)
        {
            db.Books entry = db.bill.books.GetEntry(bookid);
            return View(entry);
        }
    }
}
