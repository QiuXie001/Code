﻿using store.Uitl.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;

namespace store.Controllers
{
    public class LoginController : BaseController
    {
        //
        // GET: /login/
        

        [HttpGet]
        [OutputCache(Duration = 10)]
        public ActionResult Login()
        {
            string Timing = TimingActionFilter.Timing;
            ViewData["Timing"] = Timing;
            ViewBag.Timing = Timing;
            return View();
        }

        [HttpPost]
        public ActionResult Login(string username,string password) 
        {
            if (username == "admin" && password == "123456")
            {
                Session["isLogin"] = true;
                ClearTempData();
                Response.ClearContent();
                return RedirectToAction("List", "Book");
            }
            else 
            {

                return Content(
      @"<div class='error'>  
           <h2>登录失败</h2>  
           <p>请检查您的用户名和密码是否正确。</p >  
             
      </ div > ",  

      "text/html");
            }
        }
        public void ClearTempData()
        {
            if (TempData.Count > 0)
            {
                TempData.Clear();
            }
        }

    }
}
