﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//存放字段的状态值（防止拼错）
namespace rui
{
    /// <summary>
    /// 资源编号 - 管控库用（和系统配置哪里保持一致）
    /// </summary>
    public enum eResourceCode
    {
       
    }
}
