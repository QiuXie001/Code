﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace db.bll
{
    /// <summary>
    /// rui
    /// 平台表
    /// </summary>
    public class rbac_Platform
    {

    }
}
