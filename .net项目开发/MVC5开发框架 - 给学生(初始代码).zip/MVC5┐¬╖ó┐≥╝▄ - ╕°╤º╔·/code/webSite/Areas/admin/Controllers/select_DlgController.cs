﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using web.Controllers;

namespace web.Areas.admin.Controllers
{
    /// <summary>
    /// 弹窗选择控制器 - 单选
    /// </summary>
    public class select_DlgController : baseController
    {
        
    }
}
