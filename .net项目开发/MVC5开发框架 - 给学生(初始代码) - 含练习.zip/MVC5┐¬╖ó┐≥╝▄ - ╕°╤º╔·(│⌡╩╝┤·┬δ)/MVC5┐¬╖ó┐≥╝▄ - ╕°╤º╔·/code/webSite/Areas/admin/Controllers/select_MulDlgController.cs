﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace web.Areas.admin.Controllers
{
    /// <summary>
    /// 弹窗选择公用控制器 - 多选
    /// </summary>
    public class select_MulDlgController : Controller
    {
        
    }
}
