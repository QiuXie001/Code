﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace rui
{
    /// <summary>
    /// 存放每个系统需要增加的内容  - 参考sysLib的同名文件
    /// </summary>
    public partial class listHelper
    {
       
    }
}
