﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rui
{
    /// <summary>
    /// 内定编码-名称对应表
    /// 通过名称获取对应的编码
    /// 
    /// 添加项目自己的代码 - 参考sysLib的同名文件
    /// </summary>
    public partial class innerCode
    {

    }
}
