package model;

/*
 * �༶
 */
public class ClassModel {
	
	private int classId;   //�༶id
	private  String className;  //�༶����
	public int getClassId() {
		return classId;
	}
	public void setClassId(int classId) {
		this.classId = classId;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	
	

}
